# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.

from .faiss_base import FaissBaseIndex
from .faiss_par_add import FaissParallelAddIndex
